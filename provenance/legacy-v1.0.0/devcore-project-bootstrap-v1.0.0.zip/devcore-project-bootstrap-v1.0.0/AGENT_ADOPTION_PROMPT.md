# Reusable agent prompt — adopt devcore-project in a repository

Adopt the workstation `dev-core` bootstrap contract in this repository.

Before changing anything:

1. Read `AGENTS.md`, README/development docs, database config, Redis config, `.env*.example`, Compose files, CI workflows, test database partition logic, and current local-infrastructure scripts.
2. Determine whether PostgreSQL and Redis are `SHARED_LOCAL`, `PROJECT_ISOLATED`, `TOOL_OWNED`, or not applicable.
3. Preserve any intentionally project-isolated performance/chaos/Supabase infrastructure.
4. Do not start, stop, recreate, delete, or reconfigure the workstation `dev-core` stack.
5. Do not print or request database password values.

For ordinary shared local infrastructure, encode a committed `.devcore/` contract using the installed `devcore-project` tool.

Workstation defaults:

```text
PostgreSQL DEV   127.0.0.1:55432
PostgreSQL TEST  127.0.0.1:55433
Redis DEV        127.0.0.1:56379
Redis TEST       127.0.0.1:56380
Canonical secrets: ~/.config/dev-core/project-db.env
```

Choose deterministic project-specific names:

```text
DEV role/database
TEST role/base database
central DEV secret key
central TEST secret key
Redis prefix
```

Use existing repository env-variable names where practical. Do not invent replacements merely to fit the bootstrap. Create templates that map generic bootstrap tokens to the repository's real variables.

Run `devcore-project init ...` only if `.devcore/` does not already exist. Then review and edit the generated contract before activation. Ensure all rendered targets are ignored by Git. Add known legacy/stale env keys to the render map purge column where necessary.

Add the local infrastructure section from `AGENTS_SNIPPET.md` to repository guidance.

Then run:

```bash
devcore-project plan
devcore-project activate
```

Activation may create project passwords and allocated project roles/databases. It does not authorize application migrations. After activation, run the repository's own migration/doctor/test workflow separately.

Redis requirements:

- prefix every shared Redis key with project/environment scope;
- TEST must add a per-run nonce if concurrent runs are possible;
- remove any shared `FLUSHDB`/`FLUSHALL` usage before using shared Redis;
- cleanup must be prefix-scoped.

PostgreSQL requirements:

- PostgreSQL 18 baseline unless this repository has an explicit documented exception;
- DEV role is non-superuser and `NOCREATEDB`;
- TEST role is non-superuser and may be `CREATEDB` only when partition database creation requires it;
- preserve existing partition suffix semantics exactly;
- never point tests at DEV.

Validation before completion:

- `devcore-project doctor` passes;
- clean TEST migration succeeds on PostgreSQL 18;
- DEV connectivity/migration is explicitly proven as authorised;
- Redis namespace isolation test preserves another project's sentinel key;
- tracked files contain no secrets;
- rendered local env files are ignored and mode `0600`;
- CI uses job-owned ephemeral PostgreSQL/Redis and matches the PostgreSQL major baseline;
- legacy infrastructure is left untouched unless retirement is separately authorised.

Report the resulting allocation, files changed, validation performed, any accepted limitations, and any legacy resources still awaiting retirement.
