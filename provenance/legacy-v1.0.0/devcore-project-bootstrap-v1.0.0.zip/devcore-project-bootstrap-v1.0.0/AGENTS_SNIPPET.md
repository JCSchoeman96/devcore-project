## Local workstation infrastructure contract

This repository uses the workstation-owned `dev-core` services. The repository and its agents MUST NOT start, stop, recreate, delete, or reconfigure the `dev-core` stack.

For a fresh worktree or after infrastructure-contract changes:

```bash
devcore-project plan
devcore-project activate
```

`devcore-project activate` is the authoritative local bootstrap. It creates missing project DB credentials in `~/.config/dev-core/project-db.env`, provisions only this project's allocated PostgreSQL roles/databases, renders ignored local env files with mode `0600`, and verifies PostgreSQL/Redis access. It never prints secrets.

Use the runner when possible so agents do not manually copy credentials:

```bash
devcore-project run dev -- <development command>
devcore-project run test -- <test command>
```

Rules:

- Read `.devcore/project.conf` and `.devcore/render-map.tsv` before changing local infrastructure assumptions.
- Treat `~/.config/dev-core/project-db.env` as the canonical workstation secret source; repo-local env files are generated copies only.
- DEV PostgreSQL and TEST PostgreSQL are physically separate shared clusters.
- Redis namespaces are key prefixes, not separate Redis databases or resources.
- Shared Redis code must never issue `FLUSHDB` or `FLUSHALL`; cleanup must be namespace/prefix scoped.
- Tests that share Redis concurrently must append a per-run nonce to the committed TEST namespace base.
- If `devcore-project doctor` fails, stop and report the dependency failure. Do not launch a project-local replacement for a shared service.
- Never run the bootstrap under shell xtrace and never print, echo, log, commit, or paste credential values.
