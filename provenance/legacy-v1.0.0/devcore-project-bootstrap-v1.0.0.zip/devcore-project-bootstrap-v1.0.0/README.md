# devcore-project bootstrap kit v1.0.0

A reusable, fail-closed local bootstrap for projects that use the shared `dev-core` PostgreSQL/Redis workstation stack.

## What this solves

A Git branch or worktree carries tracked configuration, but ignored `.env*` files do not follow Git history. That is why an old worktree can be rebased to a post-migration commit and still point at an obsolete local database. This tool makes worktree activation explicit and repeatable.

The model is:

```text
repo .devcore/ contract (tracked, no secrets)
                  |
                  v
        devcore-project activate
          |                 |
          v                 v
~/.config/dev-core/      dev-core Docker stack
project-db.env           PG DEV / PG TEST / Redis DEV / Redis TEST
(canonical secrets)          |
          |                  |
          +--------+---------+
                   v
           ignored local env files
                mode 0600
```

## Installation

```bash
mkdir -p "$HOME/.local/bin"
cp bin/devcore-project "$HOME/.local/bin/devcore-project"
chmod 700 "$HOME/.local/bin/devcore-project"
"$HOME/.local/bin/devcore-project" install
```

Make sure `~/.local/bin` is on `PATH`.

`install` only creates configuration files. It does **not** create or operate Docker services.

## Workstation defaults

The generated `~/.config/dev-core/dev-core.conf` defaults to:

```text
PostgreSQL DEV   127.0.0.1:55432  dev-core-postgres-dev-1
PostgreSQL TEST  127.0.0.1:55433  dev-core-postgres-test-1
Redis DEV        127.0.0.1:56379  dev-core-redis-dev-1
Redis TEST       127.0.0.1:56380  dev-core-redis-test-1
Postgres admin   devcore_admin
```

Edit that global file only if the workstation contract itself changes.

## Add a new project

From the repository root:

```bash
devcore-project init \
  --project-key myapp \
  --dev-role myapp_dev \
  --dev-db myapp_dev \
  --test-role myapp_test \
  --test-db myapp_test \
  --redis-prefix myapp \
  --test-createdb yes
```

This creates `.devcore/` files containing no secrets. Then:

1. Adjust `.devcore/env.local.template` so the left-hand environment-variable names match the application exactly.
2. Ensure the local target (default `.env.local`) is ignored by Git.
3. If old worktrees may contain obsolete env names, add them to the fourth `render-map.tsv` column as a comma-separated purge list.
4. Commit `.devcore/` and the AGENTS instructions.
5. Run:

```bash
devcore-project plan
devcore-project activate
```

## What `activate` does

It is idempotent and project-scoped:

- creates missing DEV/TEST secrets in `~/.config/dev-core/project-db.env` using 256-bit random hex values;
- creates or refreshes the allocated project login roles;
- enforces `NOSUPERUSER`, `NOCREATEROLE`, `NOREPLICATION`, and `NOBYPASSRLS`;
- keeps DEV `NOCREATEDB`;
- optionally gives TEST `CREATEDB` for Ecto partition databases;
- creates the allocated databases if absent and refuses to silently adopt a database owned by another role;
- renders only ignored local env files and sets them to `0600`;
- removes stale copies of managed/purged env keys while preserving unrelated local settings;
- authenticates to both PostgreSQL clusters using the project roles;
- PINGs both Redis services and writes/deletes a short-lived key only inside the project's namespace.

It does **not** start/stop/recreate Docker services and never runs `FLUSHDB` or `FLUSHALL`.

## Redis "namespace creation"

Redis has no namespace object to create. A namespace is a deterministic key prefix:

```text
myapp:dev:...
myapp:test:<run-id>:...
```

`devcore-project` verifies that scoped keys can be written. The application is still responsible for using the prefix on every Redis key. Concurrent tests should add a unique per-run nonce to `myapp:test`.

## Multiple local env files

`render-map.tsv` supports separate DEV and TEST files:

```text
# PROFILE  TEMPLATE                                  TARGET                  PURGE_KEYS
dev        .devcore/env.development.local.template  .env.development.local DATABASE_URL,DB_HOST,DB_PORT
test       .devcore/env.test.local.template         .env.test.local        DATABASE_URL,DB_HOST,DB_PORT
```

The actual file uses tab separators.

Then run commands without manually copying secrets:

```bash
devcore-project run dev -- mix phx.server
devcore-project run test -- mix test
```

Rows with profile `all` are loaded for every profile.

## Credential rotation

```bash
devcore-project rotate
```

This rotates both DB credentials, synchronizes the PostgreSQL roles, re-renders the ignored env files, and runs `doctor`. It does not print the old or new values. If DB synchronization fails, it attempts to restore the prior credentials.

## Existing project migration

For an existing project, do not immediately delete old containers or volumes. First encode the new `.devcore/` contract, activate it, run clean migrations and tests, prove DEV/TEST isolation, stop using the legacy stack, and only retire old infrastructure in a separate deliberate pass.

## Security properties

- Central secret directory: mode `0700`.
- Central secret file: mode `0600`.
- Rendered local env files: mode `0600`.
- Refuses to write a secret-bearing target that Git does not ignore.
- Refuses secret handling under shell xtrace.
- Does not `source` committed project configuration.
- The `run` command parses local env files literally rather than evaluating shell code.
- Generated passwords use a restricted character set so they are safe for the PostgreSQL provisioning path.
- Project DB/database identifiers are strictly validated before they reach SQL.

## Recommended repository files

```text
.devcore/
├── project.conf
├── render-map.tsv
├── env.local.template              # or separate dev/test templates
└── README.md
AGENTS.md                            # include AGENTS_SNIPPET.md guidance
```

The `.devcore/` directory is part of repository truth. Local rendered `.env*` files remain ignored workstation state.
