# DEVCORE PROJECT BOOTSTRAP STANDARD

Version: **1.0.0**  
Status: **Working local-development standard**  
Scope: repositories that use the shared workstation `dev-core` PostgreSQL and/or Redis services.

## 1. Purpose

The repository must carry enough non-secret infrastructure truth that a new agent or a fresh Git worktree can discover the current local-development topology without relying on chat history. Secrets remain workstation-local and must never become repository authority.

The standard therefore separates:

- **tracked project allocation** — database names, role names, Redis prefix, env-file mapping;
- **workstation secret authority** — `~/.config/dev-core/project-db.env`;
- **workstation service authority** — the Dockge-owned `dev-core` stack;
- **generated worktree state** — ignored `.env*` files with mode `0600`.

## 2. Canonical workstation endpoints

Unless the workstation-global `~/.config/dev-core/dev-core.conf` explicitly supersedes them:

```text
PostgreSQL DEV   127.0.0.1:55432
PostgreSQL TEST  127.0.0.1:55433
Redis DEV        127.0.0.1:56379
Redis TEST       127.0.0.1:56380
```

Current service containers:

```text
dev-core-postgres-dev-1
dev-core-postgres-test-1
dev-core-redis-dev-1
dev-core-redis-test-1
```

Projects MUST NOT lifecycle-manage those services.

## 3. Required repository contract

A project using this standard SHOULD commit:

```text
.devcore/
├── project.conf
├── render-map.tsv
├── one or more *.template files
└── README.md
```

`project.conf` contains no secrets and records at minimum:

```text
PROJECT_KEY
DEV_DB_ROLE
DEV_DB_NAME
TEST_DB_ROLE
TEST_DB_NAME
DEV_SECRET_KEY
TEST_SECRET_KEY
TEST_ROLE_CREATEDB
USE_REDIS
REDIS_PREFIX
RENDER_MAP
```

The config is declarative. It is not shell code and MUST NOT be sourced.

## 4. Worktree activation invariant

A worktree is not considered locally activated merely because its tracked branch is current.

Ignored local files can predate the branch and can retain obsolete endpoints, usernames, or passwords. Therefore, after creating a worktree, rebasing across an infrastructure-contract change, or rotating credentials, run:

```bash
devcore-project plan
devcore-project activate
```

Only then should repository-specific development or tests start.

## 5. Secret authority

`~/.config/dev-core/project-db.env` is the canonical local source for project database passwords.

Requirements:

- directory mode `0700`;
- file mode `0600`;
- one DEV and one TEST password key per project;
- generated passwords SHOULD be at least 256 bits of cryptographic randomness;
- passwords MUST NOT be printed, committed, pasted into chat, or placed into tracked configuration;
- repo-local `.env*` copies are generated cache/state, not authority.

## 6. PostgreSQL allocation

Each project receives a distinct DEV role/database and TEST role/base database.

Application roles MUST be:

```text
LOGIN
NOSUPERUSER
NOCREATEROLE
NOREPLICATION
NOBYPASSRLS
```

DEV defaults to `NOCREATEDB`.

TEST may use `CREATEDB` where the repository creates `MIX_TEST_PARTITION` or equivalent databases. This is an accepted local-development limitation: PostgreSQL does not constrain `CREATEDB` to a name prefix. The TEST cluster is physically separate from DEV to bound this privilege.

The bootstrap MUST refuse to silently adopt an existing database owned by another role.

## 7. Redis namespace contract

Redis has no namespace object to provision. A namespace is a key prefix.

Canonical shape:

```text
<project>:dev:...
<project>:test:<run-nonce>:...
```

The bootstrap may verify namespace write access by creating and deleting a short-lived probe key only within the project prefix.

Application/test code sharing Redis MUST:

- prefix all keys;
- use a per-run TEST nonce where concurrent test processes can overlap;
- perform prefix-scoped cleanup only;
- never use `FLUSHDB` or `FLUSHALL` on shared Redis.

## 8. Rendered environment files

The tracked `render-map.tsv` maps profiles and templates to ignored local targets.

Example:

```text
dev<TAB>.devcore/env.development.local.template<TAB>.env.development.local<TAB>DATABASE_URL,DB_HOST,DB_PORT
test<TAB>.devcore/env.test.local.template<TAB>.env.test.local<TAB>DATABASE_URL,DB_HOST,DB_PORT
```

The optional fourth column lists obsolete variable names to purge from stale worktree files.

The bootstrap MUST:

- refuse to write a secret-bearing file that Git does not ignore;
- preserve unrelated local settings;
- replace only its managed block and explicitly purged keys;
- set generated local files to mode `0600`.

## 9. Activation behavior

`devcore-project activate` MAY:

- create missing central project passwords;
- create/alter only the allocated project roles;
- create only the allocated project DEV/TEST databases;
- render ignored env files;
- authenticate to project databases;
- perform scoped Redis probe reads/writes.

It MUST NOT:

- start, stop, restart, recreate, delete, or reconfigure `dev-core`;
- delete arbitrary databases;
- touch another project's roles/databases;
- execute `FLUSHDB`/`FLUSHALL`;
- run destructive project migrations/resets automatically;
- delete legacy project containers or volumes.

Repository-specific migrations remain a separate explicit step after activation.

## 10. Credential rotation

Credential rotation is a coordinated operation between:

```text
central secret file
        +
PostgreSQL role password
        +
rendered local env copies
```

`devcore-project rotate` rotates DEV and TEST together, synchronizes both roles, re-renders local files and performs validation. A failed synchronization must attempt to restore the previous credential pair.

## 11. Agent behavior

Agents working in a compliant repository should not need migration-history prompts.

They MUST first read:

```text
AGENTS.md
.devcore/project.conf
.devcore/render-map.tsv
```

For a new/fresh/stale worktree they should use the bootstrap rather than manually copying secrets.

If activation or doctor fails, the agent must stop and report the dependency failure. It must not resurrect a legacy project-local PostgreSQL/Redis stack as a workaround.

## 12. Pure/no-database repositories

A repository that does not consume shared data services should not add this machinery merely for uniformity. Mark PostgreSQL/Redis as not applicable in its repository guidance instead.

## 13. Migration/retirement boundary

Adopting this bootstrap does not authorize legacy infrastructure deletion.

The sequence remains:

```text
encode contract
→ activate current worktree
→ migrate/validate application
→ prove DEV/TEST isolation
→ stop relying on old stack
→ observe normal development
→ separately approve backup/retirement
```

Legacy containers, databases and volumes are evidence/rollback assets until deliberately retired.
