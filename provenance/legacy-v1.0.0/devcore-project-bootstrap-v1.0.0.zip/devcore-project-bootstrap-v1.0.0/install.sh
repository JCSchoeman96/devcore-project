#!/usr/bin/env bash
set -euo pipefail
set +x
umask 077

HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TARGET="$HOME/.local/bin/devcore-project"
mkdir -p "$HOME/.local/bin"
install -m 700 "$HERE/bin/devcore-project" "$TARGET"
"$TARGET" install
printf 'PASS: installed %s\n' "$TARGET"
